<div class="footer bg-gray-200 mb-4">
    <p>&copy; ExternAlliance {{ date('d m Y') }} Admin Dashboard. All Rights Reserved</p>
 </div>
