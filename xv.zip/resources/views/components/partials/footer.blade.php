<div class="footer-wrap pd-20 mb-20 card-box">
    KondroNetworks -  Admin Template By
    <a href="https://github.com/tcotidiane33" target="_blank"
        >Supernova</a
    >
</div>